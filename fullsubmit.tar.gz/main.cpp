// Project identifier: 0E04A31E0D60C01986ACB20081C9D8722A1899B6

#include <iostream>
using namespace std;

int main() {
  // TODO: implement main function to read input, perform analysis, and output results
  cout << "Hello World" << endl;
  return 0;
}